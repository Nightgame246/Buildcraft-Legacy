# Session Restore - Buildcraft-Legacy Portierung

## Aktueller Status: Phase B (Spezialisierte Rohre) - FORTGESETZT

### 1. Abgeschlossene Baustellen (Heute):
- **Eisenrohr (Iron Pipe) Fix**: 
    - Rendering-Fehler behoben (Synchronisation zwischen BlockEntity und Client).
    - Textur-Diskrepanzen im Mixin-System (`ModelUtils.java`) gelöst.
    - Der Output-Ring (solides Eisen) wird nun korrekt gerendert und rotiert mit dem Wrench.
- **Diamantrohr (Diamond Pipe) Portierung**:
    - **Logik**: Komplette Sortier-Logik basierend auf dem Original (Prioritäten/Ausschluss) implementiert.
    - **Assets**: Alle 7 originalen Texturen (Base + 6 Richtungs-Farben) aus dem 1.12 Repository migriert.
    - **GUI**: Originale `filter.png` eingebunden und alle 54 Slots pixelgenau auf die Textur ausgerichtet.
    - **Infrastruktur**: `DiamondItemPipeBlock` erstellt, um das GUI korrekt zu öffnen.

### 2. Nächste Ziele (Nächste Session):
- **Smaragdrohr (Emerald Item Pipe)**:
    - Logik für Filter-Extraktion implementieren (nur Items extrahieren, die im Filter liegen).
    - GUI-Anpassung (ähnlich wie Diamant, aber nur 9 Slots/eine Richtung).
- **Lapis- & Daizuli-Rohre**:
    - Farbsystem für Items in Rohren.
    - Routing-Logik basierend auf Item-Farben.

### 3. Wichtige Hinweise:
- Bei Änderungen an Rohr-Texturen in `BCPipes.java` muss zwingend die entsprechende Config-Datei in `run/config/buildcraft/pipes/` gelöscht werden, da diese nicht automatisch überschrieben wird.
- `runData` muss nach Modell-Änderungen ausgeführt werden, um die JSON-Dateien in `src/generated/resources` aktuell zu halten.
